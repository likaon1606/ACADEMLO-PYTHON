n = 2
power = 0 
val = n

while val < 1000:
    power = power +1 
    val = val *n
    break
print(power)
