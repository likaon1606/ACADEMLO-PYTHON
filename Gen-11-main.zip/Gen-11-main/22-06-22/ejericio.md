Dado el siuiente string valida sio estan balanceados o no
"[[[[][]]]]"
[][]][ 