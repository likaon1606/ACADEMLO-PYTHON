# Data Type ->  Es un item, o elemento que define el tipo y el rango
# de valores que puede tomar.

# Numbers - Strings - Booleans

# Variables -> Un nombre que tienge un valor asigando 

income = 480
Income = 470

inc3ome2 = 789

_name = "Nico"
name_ = "Nico 2"

print(name_)
print(_name)
print(income)
print(Income)
print(inc3ome2)

EDAD = 78
print(EDAD)
EDAD = 45
print(EDAD)

print(name_, EDAD)


# Numeros - Enteros - int
numero = 84448
numero_b = -87419
print(numero)
print(numero_b)

print(
    type(numero)
)
# Numeros - Flotantes - float
numero = 7793.45
print(numero)
print(type(numero))


# Numeros - Complejos - complex
numero = complex(10,20) # 10 + 20j
print(numero)
print(type(numero))

# Booleans - bool
print(True)
print(False)

print(True + 0)
print(False + 0)

name = "Nico"
print(type(name))
name = 'Nic 6 #o'
print(type(name))
name = """Nico""" 
print(type(name))
quote = """
This is a great
quoate
"""
print(type(quote))

random_string = "I am Batman"
print(len(random_string))

batman = "Bruce Wayne"
first = batman[0]
print(first)
incognit = batman[5]
print(incognit)

print(batman[len(batman) - 1])
print(batman[-1])

name = "Alexandra"
print(name)

name = "Diego"
name = 89

print(name)






