print(
    "Hola Mundo! 1"
)
print(
    'Hola Mundo 2'
)
print(
    """
    
    Hola Mundo 3"""
)
print(
    '''
    
    Hola Mundo 4'''
)
# STRING -> Cadena de caracteres

print(50)
print(1000)
print(3.14)

print(50,1000,"Hello World")

#print("Hellow", end="")
#print("world \n")
#print("aaaa ")
print("bbbb \n")   

"""
print(50)
print(1000)
print(3.14)
"""

# DOCSTRING
# TODO: Falta agregar el idioma ingles