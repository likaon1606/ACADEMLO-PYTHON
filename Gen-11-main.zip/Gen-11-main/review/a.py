a = "Hola "
b = "Mundo"
c = a +b
a = a +b 

print(a)