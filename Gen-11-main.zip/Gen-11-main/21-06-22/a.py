string = "Hola"
string = string.zfill(8)
print(string)