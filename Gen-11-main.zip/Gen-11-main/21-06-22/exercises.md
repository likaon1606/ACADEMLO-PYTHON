# Ejercicio 1
Crea un string hecho del primer caracter, del  caracter del medio y el caracter final

str1  = "James"
-> Jms

# Ejercicio 02

Crea un caracter hecho de los tres caracteres del medio 

str1 =  "JhonDipPeta"
-> Dip

# Ejercicio 03
Dados dos string, s1 y s2.
Escribe un programa para crear un nuevo string s3 agregando s2 en 
el medio de s1

s1 = "Ault"

s2 = "Kelly"

-> AuKellylt


# Ejercicio 4
Crea un nuevo string hecho del primer, el del medio y el final caracter de cada string existente.

s1 = "America"

s2 = "Japan"

-> AJrpan


# Ejercicio 5
Despues de haber visto todos los métodos que tenemos disponible para los strings es momento de poner todo ese conocimiento en practica


## Dado el siguiente texto
IT was a special pleasure to see things eaten, to see things blackened and changed. With the brass nozzle in his fists, with this great python spitting its venomous kerosene upon the world, the blood pounded in his head, and his hands were the hands of some amazing conductor playing all the symphonies of blazing and burning to bring down the tatters and charcoal ruins of history. - FAHRENHEIT 451

## Aplicaremos los metodos que acabamos de ver para obtener el siguiente resultado
It was a special pleasure to see things eaten, to see things blackened and changed. with the brass nozzle in his fists, with this great python spitting its venomous kerosene upon the world, the blood pounded in his head, and his hands were the hands of some amazing conductor playing all the symphonies of blazing and burning to bring down the tatters and charcoal ruins of history. - Fahrenheit 451

  