
def suma():
    pass

def multiplicar():
    pass