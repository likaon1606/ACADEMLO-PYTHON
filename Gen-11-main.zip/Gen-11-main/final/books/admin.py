from django.contrib import admin

from .models import Book, BookItem

admin.site.register(Book)
admin.site.register(BookItem)